BHARAT RISING - DOC PACK v2
Start with: Story_Full.txt and World_Map_India.txt (they replace the old
6-act story and the 6 fictional cities). Other files: PRD, game, asset,
Game graphics, tech_architecture, Prompt.
Names of people, companies, parties and agencies are fictional; places
are real India.
